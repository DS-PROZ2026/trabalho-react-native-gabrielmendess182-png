import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Qual filme ganhou o Oscar de Melhor Filme em 2024?',
    opcoes: ['Barbie', 'Oppenheimer', 'Pobres Criaturas', 'A Zona de Interesse'],
    respostaCerta: 1
  },
  {
    id: 2,
    pergunta: 'Quem dirigiu a trilogia "O Senhor dos Anéis"?',
    opcoes: ['Steven Spielberg', 'James Cameron', 'Peter Jackson', 'Ridley Scott'],
    respostaCerta: 2
  },
  {
    id: 3,
    pergunta: 'Em "Titanic" (1997), qual música toca na cena final?',
    opcoes: ['My Heart Will Go On', 'Hero', 'Endless Love', 'Because You Loved Me'],
    respostaCerta: 0
  },
  {
    id: 4,
    pergunta: 'Qual ator interpretou o Coringa em "Batman: O Cavaleiro das Trevas"?',
    opcoes: ['Jack Nicholson', 'Joaquin Phoenix', 'Heath Ledger', 'Jared Leto'],
    respostaCerta: 2
  },
  {
    id: 5,
    pergunta: 'Qual estúdio produziu "Toy Story", o primeiro longa-metragem totalmente animado por computador?',
    opcoes: ['DreamWorks', 'Disney', 'Pixar', 'Blue Sky'],
    respostaCerta: 2
  },
  {
    id: 6,
    pergunta: 'Em qual país se passa a história do filme "Parasita" (2019)?',
    opcoes: ['Japão', 'China', 'Coreia do Sul', 'Tailândia'],
    respostaCerta: 2
  },
  {
    id: 7,
    pergunta: 'Qual frase icônica é dita por Darth Vader em "Star Wars"?',
    opcoes: ['May the Force be with you', 'I am your father', 'Do or do not', 'Help me, Obi-Wan'],
    respostaCerta: 1
  },
  {
    id: 8,
    pergunta: 'Quantos filmes compõem a saga principal do Marvel Cinematic Universe (Fases 1 a 3)?',
    opcoes: ['18', '21', '23', '25'],
    respostaCerta: 2
  },
  {
    id: 9,
    pergunta: 'Quem escreveu o roteiro original de "Pulp Fiction"?',
    opcoes: ['Martin Scorsese', 'Quentin Tarantino', 'David Fincher', 'Joel Coen'],
    respostaCerta: 1
  },
  {
    id: 10,
    pergunta: 'Qual filme tem a frase: "Vida é como uma caixa de chocolates"?',
    opcoes: ['Big Fish', 'Cast Away', 'Forrest Gump', 'The Green Mile'],
    respostaCerta: 2
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  // Missão 2: estados de feedback
  const [respostaSelecionada, setRespostaSelecionada] = useState(null);
  const [bloqueado, setBloqueado] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setTelaAtual('quiz');
    setRespostaSelecionada(null);
    setBloqueado(false);
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (bloqueado) return;

    // Missão 2: feedback imediato + bloqueio
    setBloqueado(true);
    setRespostaSelecionada(indiceClicado);

    // Só mostra o loading após 1 segundo
    setTimeout(() => {
      setCarregando(true);
      setRespostaSelecionada(null);
      setBloqueado(false);

      const pergunta = QUIZ[perguntaAtual];
      if (indiceClicado === pergunta.respostaCerta) {
        setPontuacao(p => p + 1);
      }

      setTimeout(() => {
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(p => p + 1);
        } else {
          setTelaAtual('resultado');
        }
        setCarregando(false);
      }, 1000);
    }, 1000);
  }

  function corDoBotao(index) {
    if (respostaSelecionada === null) return styles.botaoOpcao;
    if (index !== respostaSelecionada) return styles.botaoOpcao;
    return index === QUIZ[perguntaAtual].respostaCerta
      ? styles.botaoCorreto
      : styles.botaoErrado;
  }

  // ==========================================
  // inicio
  // ==========================================
  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>🎬</Text>
        <Text style={styles.tituloPrincipal}>Quiz do Cinema</Text>
        <Text style={styles.subtituloInicio}>Você é um verdadeiro cinéfilo?{'\n'}Teste seus conhecimentos!</Text>
        <TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
          <Text style={styles.textoBotaoIniciar}>🎥  INICIAR JOGO</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ==========================================
  // final
  // ==========================================
  if (telaAtual === 'resultado') {
    const nota = pontuacao / QUIZ.length;
    const emoji = nota >= 0.8 ? '🏆' : nota >= 0.5 ? '🎬' : '🎞️';
    const mensagem = nota >= 0.8 ? 'Crítico profissional!' : nota >= 0.5 ? 'Bom cinéfilo!' : 'Precisa ver mais filmes!';
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>{emoji}</Text>
        <Text style={styles.titulo}>{mensagem}</Text>
        <Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
        <TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
          <Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ==========================================
  // carregamento
  // ==========================================
  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#e11d48" />
        <Text style={styles.textoCarregando}>Validando resposta...</Text>
      </View>
    );
  }

  // ==========================================
  // TELA DO QUIZ
  // ==========================================
  const pergunta = QUIZ[perguntaAtual];

  return (
    <View style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>🎬 {perguntaAtual + 1} / {QUIZ.length}</Text>
        <Text style={styles.pontos}>⭐ {pontuacao} pts</Text>
      </View>

      <View style={styles.cartaoPergunta}>
        {/* Missão 1: imagem da pergunta */}
        <Image source={{ uri: pergunta.imagem }} style={styles.imagemPergunta} />
        <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => (
          <TouchableOpacity
            key={index}
            style={corDoBotao(index)}
            onPress={() => responder(index)}
            activeOpacity={0.7}
            disabled={bloqueado}
          >
            <Text style={styles.textoOpcao}>{opcao}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// ==========================================
// estiloss
// ==========================================
const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#0f0f0f', padding: 20, paddingTop: 60 },
  telaCentrada: { flex: 1, backgroundColor: '#0f0f0f', justifyContent: 'center', alignItems: 'center', padding: 20 },
  iconeGrande: { fontSize: 80, marginBottom: 20 },
  tituloPrincipal: { fontSize: 36, fontWeight: '900', color: '#f8fafc', marginBottom: 10, textAlign: 'center' },
  subtituloInicio: { fontSize: 16, color: '#94a3b8', marginBottom: 50, textAlign: 'center', lineHeight: 24 },
  botaoIniciar: { backgroundColor: '#e11d48', paddingVertical: 20, paddingHorizontal: 40, borderRadius: 20, width: '100%', maxWidth: 300, alignItems: 'center', elevation: 8 },
  textoBotaoIniciar: { color: 'white', fontSize: 20, fontWeight: '900', letterSpacing: 1 },
  cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20, paddingHorizontal: 5 },
  progresso: { fontSize: 16, fontWeight: '700', color: '#94a3b8' },
  pontos: { fontSize: 16, fontWeight: '800', color: '#fbbf24' },
  cartaoPergunta: { backgroundColor: '#1e1e1e', borderRadius: 20, marginBottom: 20, overflow: 'hidden', elevation: 5 },
  imagemPergunta: { width: '100%', height: 160, resizeMode: 'cover' },
  textoPergunta: { fontSize: 18, fontWeight: '800', color: '#f1f5f9', textAlign: 'center', lineHeight: 26, padding: 20 },
  areaOpcoes: { flex: 1 },
  botaoOpcao: { backgroundColor: '#1e1e1e', padding: 18, borderRadius: 14, marginBottom: 12, borderWidth: 2, borderColor: '#334155' },
  botaoCorreto: { backgroundColor: '#14532d', padding: 18, borderRadius: 14, marginBottom: 12, borderWidth: 2, borderColor: '#22c55e' },
  botaoErrado: { backgroundColor: '#450a0a', padding: 18, borderRadius: 14, marginBottom: 12, borderWidth: 2, borderColor: '#ef4444' },
  textoOpcao: { fontSize: 16, color: '#f1f5f9', fontWeight: '600', textAlign: 'center' },
  titulo: { fontSize: 28, fontWeight: '900', color: '#f8fafc', marginBottom: 10, textAlign: 'center' },
  subtitulo: { fontSize: 18, color: '#94a3b8', marginBottom: 40, textAlign: 'center' },
  botaoAcao: { backgroundColor: '#e11d48', paddingVertical: 18, paddingHorizontal: 40, borderRadius: 16, width: '100%', maxWidth: 300, alignItems: 'center' },
  textoBotaoAcao: { color: 'white', fontSize: 18, fontWeight: '800' },
  textoCarregando: { marginTop: 20, fontSize: 18, fontWeight: '600', color: '#e11d48' }
});