import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function App() {
  const [expressao, setExpressao] = useState('');
  const [resultado, setResultado] = useState('0');

  const calcular = (texto) => {
    try {
      const limpa = texto.replace(/×/g, '*').replace(/÷/g, '/');
      if (limpa === '' || /[+\-*/.]$/.test(limpa)) return;
      let valor = eval(limpa);
      if (!isFinite(valor)) {
        setResultado('Erro');
        return;
      }
      valor = Math.round(valor * 100000) / 100000;
      setResultado(String(valor));
    } catch (e) {
      setResultado('Erro');
    }
  };

  const apertar = (tecla) => {
    if (tecla === 'C') {
      setExpressao('');
      setResultado('0');
      return;
    }
    if (tecla === '⌫') {
      const nova = expressao.slice(0, -1);
      setExpressao(nova);
      calcular(nova);
      return;
    }
    if (tecla === '=') {
      calcular(expressao);
      return;
    }

    const operadores = ['+', '-', '×', '÷'];
    const ultimo = expressao.slice(-1);

    if (operadores.includes(tecla)) {
      if (expressao === '' && tecla !== '-') return;
      if (operadores.includes(ultimo)) {
        const nova = expressao.slice(0, -1) + tecla;
        setExpressao(nova);
        return;
      }
    }

    if (tecla === '.') {
      const partes = expressao.split(/[+\-×÷]/);
      const atual = partes[partes.length - 1];
      if (atual.includes('.')) return;
    }

    const nova = expressao + tecla;
    setExpressao(nova);
    calcular(nova);
  };

  const teclado = [
    ['C', '⌫', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '.', '=']
  ];

  const corDaTecla = (tecla) => {
    if (tecla === '=') return styles.teclaIgual;
    if (tecla === 'C' || tecla === '⌫') return styles.teclaLimpar;
    if (['+', '-', '×', '÷'].includes(tecla)) return styles.teclaOperador;
    return styles.teclaNumero;
  };

  const corDoTexto = (tecla) => {
    if (tecla === '=') return styles.textoIgual;
    if (tecla === 'C' || tecla === '⌫') return styles.textoLimpar;
    if (['+', '-', '×', '÷'].includes(tecla)) return styles.textoOperador;
    return styles.textoNumero;
  };

  return (
    <ImageBackground
      source={{ uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTEhIWFhUXGBgXFxgVGBgaGBcYFhcXFxcYGhgYHyggGB0mGxcYITEiJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGhAQGy0mHyUtLS0rLSstLS0vLS0tLS0tLS0uLy0tLS0tLS0tLS0tLS0tLS0tLy0tMCstLS0tLS0tLf/AABEIAOUA3AMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAADAAECBAUGBwj/xABBEAABAgQEAggFAgQEBQUAAAABAhEAAyExBBJBUWFxBRMiMoGRofAGQrHB0VLhBxRi8SNygqIkM1NzkhVDsrPC/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/EAC8RAAIBAwMCBAUEAwEAAAAAAAABAgMRIRIxQQRREyJh8HGBobHBBTLR4SOR8RT/2gAMAwEAAhEDEQA/APD3hoUKABQ6UvaGhwYQFiQzjMHa4FCRz0rE5UwBwwI59kbE/qgOcMNeGnjvEVEmGKwYz7fNz7ocVDa6eUDWsk1eIRew2ECw4JKnrskWCirZzpCHsVlJZin6uabgWjd+EegDj8SiUVsC65iu8UoR3iajK9g+4jHUoMQ/aoBlDJ2LkVU4j03+D2ASmTOxCrKmiS+yUSytVdjmSDAXThqkkWfi6YlOWWhkypaQmWgAMAB2SqtXDMDu4Og5ObMcu9+egAPHTnzjd+J5/WTFL+Ul0ilQa5jwNwLFyaGkc3NVVquW04fnfwMczd2z6W2iMeMBzOADMNBUjcb0A5ekSEz23jr5+NtYqEuKggUN60OjPp484tnCKZwaM9n5mmldKCtoT2QRacnZXKk4hzSx2Gw9/mG65rONHHEvqWHusAmPmIJ9NKcd9fWBAh6nawHDfmNuAjRbnFKdo7c/k3sHjVDTMn+nvC7ULvztWgjpOhMIlUqgzp7QmJNbmoS2rVIBFA5IArw2GUQXf39fvxEdh0KtSDnl3+dIsoC9DTMAxexar2iNkdCep3XZ/g4j4i6KOHmrlKqEkFJ/UhQdCnsaaijgxnqsCI9C/iSlMxEiaGBYoLX7WZaXe/dVdzuxoPP5YcEO8d0MxTPmOoh4dRx7P7kJjAlwa1BB9uIjNFIJPQwBFWpbSIPeB7maeEw2GXb05/iLeLLoHBXGyq/URn4Q1A46/tG/isCerVTS+mig24qa8IfA+Sh0JiurmuyDQ98smjF30YPWF0rh5kuapgCkFwRsaisUcOtlAsGeoNQRseEb3SQcIW10sooLoJYB2NqgAW+sRyU1gwpmI7eYCmv3hypy7twh8SKGKy1F7w3gm1yiBDkQkmJGsQbkQIXhCBgkxhQF+Vv7wAPh5TkA0e1Hc7CCTZYzkAKAGhIKgwq5teAZjvCA1gAKkirhywAagd6vvSHAIcEsLkVuP6eHGGlOWCRV7h3Nm9frEZhLl7uXq5fidYQDlYcFLgtUvV9SNo9y+AMBm6BQwSSuZMWQqxAmZTQXolm1tHhy5zhmAGw3Zn5x9Efw0SP/AEXDP+mb/wDdMgNaGJo88+JZ2aYoiiXLF7tRxS1y7V1AMYKx2aWcj0BDkvzq4L3F43viYkr5cCKCjj8/WOdIDCrsQabktcaHgPCOe2We/Vkko8sNhQVEgCraOTuKX1LXGxjazsgvQs5Be9akEXtdj/UYwsFMZaNnD1dxrqfQxfkzAEsptrV2dwwHhl8YTtYVNybdrbGXiC55/Xfd6jQml4FlOVV9Dru+nhueMGxUxilnq/M9rkPoeUD605CXqFJ21BeNFa5yz1W+f5IYGq0peilBPmWNudh4x1vQuKcle5JIrxZTn628QG5XoubnmJSsBh2iWqEoBWqoY2BjoOhikB0KLi6Vd6moIqrkz0pqUzJYHRmtXmOg+MsMk9HzFhNZc2SQX3MxJDfK3WGlbs8eXzKKuGj1L4hmg9ETXN1ydGZ1hh5Ae2jyrELoA3CN6L8h5PXp/wDod+weQkEFLuVA6mhFgxEU5cFw8xiDsQfKLUuRLVNLzAhBJIUoKyihUAQkFVw1BG26OPZtFGVeOjx/SBTly5VggKDhmzJZSGFKF6i78YywE3BTSoGU1Yi73HCLfSUsFeZCQJZYpAfIHDqCSdAommnqXYlyuZEkDOkKokqAJ2BLE+UXsfmSpSAt0gsxpVN7cXPjFHEIqzV/MX5TziMxSS1rFgLlqGJSyVKVlcpKJsTAlAbwbEygk3B2YvAFHlAxxyiiIcGIw8Zm45ESlpejV0+8REFRLGUqzcAGvrfSAAhw7O7FtrB2auusCSB8z8Gg0+YkoSz5tXsBsNhAHJhCRNcy+UFIOgNPHeBkRKW1CajZ29YZReAYhH0F/CRZmdDoQPlXNQa2BXm//ceCSsMrL1mR0j9VAfz4cI9d/hFiFSsBiULBT/iomVFcsxAALHQlArAzSn+9WMj4vYTFJCgoOB4Vy+Re24jmMLJJJGhBbYkVTTWoH5ieFxScvWDtIJJUg1yZjWn6XJHAlO8DnTClQrYuCKOL0jOcHGWT2KdZV6a04/klhsoIKip9QPIOak+IPCLaZkkOCmaS5stIF7jsPVxveM+Z3mHAjxY2/tB5siY/cXYP2T+kAP5RNila6bZKYJJCSUzGIcMtAN9TkbThEFS5QTQrAJ1YlwBsBvBJuDmshpUw9jRCj86+DxVxktSUpCklNz2gRdR34CKyRpjZZ57ksDh26xSFJV2cgrlPbob0sFWJi10ckiYkOUsavQgCvv7tFBZyoQnd1n/4pfkAo/6okjpVOeWmd2pSVJMyjqKAayxWzWBsdhSDTdmUqngxbebnb/xCnBHR4SKGZOluB/SiYolvLzjy+bMOsd//ABI6UE1OHKAEpmmZOADUScoRbgT5cY4yRlWpjY/WNKcbRseZ1dXVU1ei+xWlTNRQ6HjGp0P0sqSiagMUzkpCksDVKnFx2bqqK1EPK6OSk5yMwALJJID6F01ptFaVZhQalo2UWcbqRawDmuouS3NnicpJJpUX2r4RaTJFH5B9eEHRhlP3SnUvQ5dxuIvSYup2B9M4xK0IQmWEFJJJGrgecZErO/Zd62jYx2FACe2CdRqCTQc2r/aM9aSKh4mWXc0ptKNkVESTchhqYeYACzv4Qaak2JppEAgRNrGuq+SgU0eIw6FNElo1Ft+MZmxCJZyzaO/jEYUIZIGCBFH2Yeb/AIgYi5hcSAClROU95gklhYB7VgEysovo3nE8OsJU5SFDZTt/tIMQWQ9LcYQEABytSlZUupgyQ1ANwPuY9B/gziiqbipBJPWYdw5esssG8F+kedpnKAoSHBBYsVAtQkXFLR1H8LMZ1XScirBeeWeOeWoJH/llgHDc52UJslRBFg6kmxSpIuNiFDzjQ6PxKVdlaSpQ7jmhF2O5jvfjLoMrxGKmSpSEvLwwS7AEDMhRDjUyBf8AePPZnR8yX2ZiVIUKhxY8NxGrgpbFUqsqUsmocYspBScrUITShdrV39IdeKmZUkLVYi5uC/j3oq4HEJU+YtosC/8AmHB/WNGXMltl6sli7lTGtCeyOVIwse1ScJK8VcBipywUstb5E2UdXP3gszFTetyiaoMyS6iR2UjMSDexNYOMRLcFUkOEp+dQsA1LcPGM3pHFywkqSFJURYkKd63ADP4wwlpjG7X2B4/H9YVEoST8qmYgPTM1FRlzMMjq3CsyyWyjStydSRtHU9A/Ci8XKBUrqwrtBquAWUWD8LsA4reNvGdD4TCmXhcMFTJ81aXmLA7rHM36duzfeKTisHjVHKpLy7bI5z4wQUrkylXk4eUkgblOc+ik+Uc+maQQRG58QTetxE2Yf1kOLEJZCam/ZA8oz8P0cuY/VoJCbq0DcY0UcHLOonJ3LMguSkniBSxqLQ0tNSGiBklGV9Q7jWtIPNa+4jeOxwz3wPIm5RYHK6bPQjQHUA0O8aUohgslGUjL21ZyARVSZdxlCiQRTN4xhJnMtjUH3aLf80l1Ep6tLJCUJAWNAxWo5khiouHc0iGzRRDY6SkyusSLkuorDqIAZpfeSw1tWMh+MaIxaVFQTLShBUOyBmKUgEUWt1Adok7lthEsH0eSpKllPVsHSaKCVHKCApgsB3oYVirpGOpT3qYJJ6PmrDpS45p+5g+JkS86gFEDNQkF2D6Cr8/ONRE+ZhkpSmSohY6wEqqQXDlKXyd21/OFbuXq7HFmE8KFGJ1ihxCiSEklgHJhDGhRq43oRUlAVMUAo2SKm1/DeKCpbc9YdidSZAgRaThiK0Hu3E8IAiNaUsBAFcwuonuioCUgUDjKXu6bw0iZSsVsbLKu0SCVOQzBuaR3RWg4QLo5S0TETJdVS1pWNgUEKDnwiE6ffK4G+/4gUlbF9NYTsONz1v4/UZ4lqQXUUpnScpIExC8qjKLVJOUKHENrHN9CfFq1qElaULzFTdYHSzE9oqsGo/CNCTjeu6Nw/wCuSVSrhygF0OBahau0cp01IStQUaLIdShq/wCr+prkXgUuD0avTuUI1YcrK9QXTypYm9ZIGVJrl2s9DcRewuJSwZIVT9RLg8A35EUEykDIovMqCpKqClMri1GqItYzFdYvMiTLlAWRKSzWubqNocrdyOn8WD2si5i8UiWntSUgsl3MwOyaXVGZ0UJU6aZk8tLSxyi6ibAPBDiFiYFXINl9oHgynv8AfSB9KTutWJqECSumYIoglPzAXBicWHW8Wdklde+De6S+M1jESlyJaUCXKXKSHzUUQXIIZLMCKaRo/CMudNmYjFkFc0SypGYgMqw7S2AAd6tRMcf0bhSpZzKckGv9R7r71joB0giWmXJWhS0v1kwJJDioDkXZlKI/AhRSukheHKlSnVnutl6sfo+VJQP+ITmWpyliCGrRvMV5Rk9LdMlZKE1Qnuj5QP8AKAATxMF+IukpK1KVIlZEqAYqehSWOQA0fjtGHiSjMrq82R+znbMRo7UeOqc+EeJSou+qQVOMUARRyak3ZiG2ar2oWIi5Jwqlpdw1aC/idIyxL3oeMXJU4guk+UTB9y6qxgL/ACK0tmAA3fgXJAqYsycQJbFIzkCmYDKOSfuYrzFbkmHQnhGiSRg5NrJufCfRpnTFZMMJqwxrRCAT3lnupHNo2kYvCyJuSfiUkDtmXgUdY63ACM2XqybvU2jj1yVqSUIJdTBgWCuB3HOM9YIo4o1E1IBGpAHAc4mcmsF06cZeZnYdChSUrXh8Ko586XmLSciSGQVEZcpzBdXajc3l4Nc51rxQlqJ7oAoGBAqRodA0UfhqTNlzUhV8meWlKwSp8q6ZVMg5cxqzOXDxpYqTMCjllSlpLMTLVMLJGTvJTluklhRyYzsbNdjzCFDkw0ZnUEcMALu5+0Hwc8oUCm/GAmWRekPLgE9jZxPSoVLCGrrMbtK/pGwG+rDxqCWACdNvpWEAClgl3LE60Gg24xLBy1THSATlDnYDcnSLRk8F+T0UqWgLLBy1Tr94CvAKmMEvR8xuL0IbxHlDT56pnVoUoFMvsJNQDsSonbgLQXE9IN2ZD5srLX+rdnsNHPpFXVjO074MpEtACxMKgpNEpABCjV3L0Y5d3c7RBSwqpIFNtmDADwL84uSsElUstmMx2DUQA4JUVHvahuIMauD6ERK7UxQJH12CbnSppGDZ6NHp51GuPUh8OvICusoFgAg0Zqgl9b+B4wTpEdtQZi5gPxKsmapb/wDMZXhz5/SKUrFFdy5HmWjN3PUpVYwXh8JY/P1L+HSBUinuoiE3DsHBcGtL+I0h5U2jEU+nEQ0xB5jhBc3SW/cjMwxcvRib84kZYVUXF/6hvz+3KJBBKyBuR57+cMWBDF9z+ICNHbcs9Gp7QJISAQSTpx8BFLpHF9ZNXOSCkOMt+yHASOHZHpAOksV8ibXP48IudDIGVWburyje1TQ8SIcW1k5uoca9qa9syJt+Gm3vWCS5FM2ZI0Z6+Ub2O+GFlBmSlBQS1P6TqDehoxHpGNI6PmgjNLUEvUs4HiKRtGSZ5VbpqtNNtYXPBXxEvLT28Swpi3MlPSABGQ8/fnGzi0ziU9Ubcml0ahKlBKkrU4LCWAVFTdkV0JvcxMYdSVFJ7woQ4v4QDBlIWkqcpcZspYlL9oAmxZ4u4ifJVMUZCCiW7JSS5AAF1alxo140V7mEv2jT5VCkjQj35CM3owoJyzJxkhVMyQSAU9pJXlDkZstg9NGi5MxgfKL8qCMxOEWtRyJUpqnKCWG5NkjnEVTTp7q6ZB2Uciiqp7TGvFjVm33jXxOHxj/4pUlRDgLWAWNQQCbVNuMUJCkgMVlzQoQNCavMPFKWZ7wKeCCykAEUrU8HJvT0aM8m7tyY0TkliDtvEBBZcrU0HuwjM6CU9bl6nn7pEAY0JPRa5lQMo/q+rXjb6K+HE5gJhBCgamiRS53AoX2fWJc0nY6aXR1ZrVay7swMCCTlANf0h1UuwEa6eiJpLsJSSKhSi5ajkAEu4fS0dLh5CkAoCstcqgGG9SdqP+mgcxYxctHUyVHupMxCmuo5s9KbKZ/6aRPivhHbH9KgrSnLHZfAwMP8PpUFFSiQAA9EgVpUv5XMPJwElANH1PFjYk19KGLk7Gk9lwlLEACiU6jzIYl6hROhgDpFzmOybC3zG5alAdHajQ5tnRDpqVNtJZ45e3vYNMkgqVUBnAPJw/ADXhWsVMZNTmLB9dgTqG4VFNAIZcwkFS6EmjWVo+7jdj9HoYlRmO5ASLkOw2pcm1/pD0ilV02tjv8A9/j/AGU8bOKqKPLhwA0HCM4Ka0HmquNNN/PWATEilfSKR51R5xg0cPiBrFnNrGEk7GLCcWRCcTpp9UreY1lzDmJ4mK2KxbO2/lFJeKUYEawJCn1V15SaDV42sD2aguNf325xjSJb+/zGzg5xQ2VNeNTs1aekNi6dO97XOjk4hSE0zJzpDcA6XO4sw3cxfwOKWXEwJUClWZwHISnOUuK/KBvyjn8MSkuTke6WzKq5YpJF2+Zt6xf/AJtJ/wCX2DQFy5UHsDYf5WqXqbRJ3K7T5/Hz9PmWJ+DkrugoOouOOuYNWrn0jM6Q+GAHUCopNQQXCakWoRUEOY28HikqDKGUChNKUaoah0HOxoDZxKkkhUtXZQhCcwoSQKki6XJNKE0vWJ1SSHPp6M5+aKv75X9/A5HCdCzS7FCmrdiQ4GobUaxrdIYb/hEhOGRJMspzLKlKm4hagQooukISACUg0oY3peGQtEx2Qs5UoNkrObMp2swHeFO0DV3iGBKkKyKol+0F0AY1J1fYjcB41XUySVzhq/o1Gbk4Nr0Z5wtyrU8Bw1MKYvKFJExTLACkoPZVlOZIX+piARePQukeipEwPlzoNiolK00zdogs5DqzWYHZowcV8M0PUqZQBISoVUE1VlXuwNGal408aMtziqfpdamtUc/c53oooMxAmdx2LHLQ7qALVbSHxrpmKSU5SFEZSSWrZw784OminWntPXd/eogWPRmVmGoDvv7aOhLGDym/NZoxpcvzjYk4TqxmX3mcA6ajxhfDGDExZUoOJYzFOii4CRycueXGC42ZmKib14WO2nIRxzZ7nRUk7zavbb+TQkLYOfOre+Ii0jEu4860NOH2jKQth7ceIqPWDGYQBq77OGJH2jFo9pTaUb7GpMxoKQC7ij6saM+7UezUIoIDOxSphyCoUyUpqAGPZbZnPrvFOTMBQou5JA4tUn7QORNKCTUhiAaul6E8aPyi1EU6i0t8cegQrHdu1+O7DYbhxDoYJKj3QSEp/Ur7JFCefGK69GroLEP4c/SCY2cCtSE9wFg9SclMz3csTfWKsYvtv68gps1cxTs5NKNQB7CjJAB5AQLFzkrOVPcT3dCSfnNbn0DCCdYUIOmdwC/yg9ptas3+lt4jJk5yGA4l+6BclqhhyhmTa5eFwyvJwQOZau6kOAfmUpxLS/Fio8EHeM8SFEgM5JYAVcmgjdx8zsoSDf8AxFc1gZH4iWEDmVbxWwSGUpf/AE0umv8A7ijlRfbtL/0CHY5HSxqtvsZOKw4SpSQXYsSKVF28YDkrGl1O4bn+YY4LQuK2tTT0r4wrifTvZGcERYkSS4NBz/Fz5RY6lqu3oIImUxb8N784AjQzZh5stAUCjukdoF+yrUCltQTVuIMXMMQXCHCqlNaqAFQSGqGJ0o4rSK0lGZaUISS4ZhUkhyCGbjprFqXMJDIQHBcFKXUCLF2JBHOEdcYXi1yhsMFEvZtSWHgB3vAE84uugVZ7OLJB4AMfMhq3aAY+SRkWQEdYkL2FXBAarAghtA0ASsJeuZ7gUB8VV/2xNjaFXVHV9EakucVEBbDRKqBtk0sONxStIuyklBCu1LbfvHdkca1NOMZEnGt3WR/Ul83/AJGo8CBGhKfsrXR7lXzNY6k0LOxs8TY6oySVsKL+fv6lyZiARmSMoTQoBsLghsoD7ixbQgCWNxHZSVEZ6O1DkA7BPIksNijg1Prglbp7RKVd8UcBwyTeoBrdrb0zOUsKU5YOSo3Jua6+b8GgaE5KPwTW+7v7+xoSukFOq5cc+0khaavUhlC9lNFo4xrpyq0chwdH+awTRhq73jn5WLZ2odSL1ozmo5DxeIy59D742091iUtiZy1auF/QbpDCZklTVDsxFb0p4ecVJqZqznUggr7VmBDmo0amkbGExLUId2DMK6+z4xc6R6XylIWVrGXsH/CPZKlECoe5MdXTT3R4n610/wC2rbOz9fUx+h8KnD9GmeoAmesj5H6tBysAe0CTnqBqIw0pVqG4atu1hHZdMpCZWCkLAIkSElSCQylrBUoAs4LGxLdobGOUxSwVOHYb95NaiNYUk8s56nVyglCnjGQYSWvQUDitPp+8IzC7Ectj7IMMVt+dDz8QIHOXoPI63sd2HrFSoQZNPr60Ws3DAu9SFOK8GtxhJxRzEEaVI8W+sUpk9Wh8DyrEEYkAl7tGDi0ehS6yMkr4d7mlLUHSq4BDmtK1rpy4xFM16qY7v61Ff7RCTMCiA2+/H7wNJan19vEM6dScr4fw+ZcmzEkgVAAarFqk8NTxizheyQxBK1JlpIemdQzGoeiXjNExJqxHKumx/MQm4opCNAFkk80sLE7mBPJlVm1Sxcv4tUx1KylKSoqAUl0hyW7waAyHWGoguSQpkg6JLFtNqRLALDsJgH+XMonwRXzi3PWh3yrUdllKPEhAUT/5CA1w5LT9Pf5ArkMkkKTb5VpPB2BfXaKqGsw+hbelbNBZqlq7qJaR/mW50uokekWcOkFJbLNyqyS0uxAGYqzgF2ASw4KNaBhZ2JnVcX5vhsUzIYlwxZy96c4mmUTlLDKQ7qLbs4oasbXDGIrxMtKkZyxSe0lLFKi7pV2rJrVJvl4mCGRiFqzArVncjshjq7rFdbDSB4IjV1ftW3bctYbGqCk5JiUlJcdWhVxqeyCrxeBzpa15qhr1IS71cIJf0iMtWUALUST8qQhNBqVtW53qIFisbKYAIr8xBJI2ASSE+MZ6r4SNcRep/wAgziWSZSi+VWZBBoAoMsB9ylB8DvBZZQQAlK1q8GO3ZSCf90VB0nMLUASAwDAeJapNT+YZM9VBm5Aj7VHpDdzOlPe1/sXcNMWCrtIQw5Gmgup6Wi7IWSlywJIVU9qgNSkdrXaMvD4dZcqFH+Zkiw3YRbYAMVU4aN/mYeXhBbJvSnZJprf48lyapgCmuhLMO0GNqmh1I5RlLxgAdR0IHjt+20Bx3SBchI8TvwH5jKVMJDm/r+0aKD5OXqOthd6cvY05OMcsAdPX6ekJE871p3QD4bD94zZE2rabD3zi6hXHwTwOpjopwieZV6mpJ5Zp9H4spU6qsFUGhYgEtQ1q3CO06MnBUsGh4kKV6mPPkr09B9zGn0fj1S0kBUpiX7SQSKCjnSkTOlZ3ib0Ot1LRXyuC307iVTJilliSHyqunTKl9gAPCOeXNq9X/wBw35xr9Nr7agXD6KrwuNI57EK9n7HSoja9oo82KvJhut1p9r2I0t6REKdubsf9NQd/oIpKX7PvhE0r8jwpX6ROsvQSmH2b+BgM2ZUV4f3iareyK/T9oApVYzkXEvyVEivqwT+8WUz3pb3o8LASn5+ZrethSCzcH5+Kj+BpFuhqV0VS6x03pexDDqSE9pJNBY5TbiC8GkpSokEsKVUKGmrH1ikZwQWVmY2NPo9qiDy2PepuBV9n1DbRySi1hnq068JpaWy9IwiU0K0gf0gk8OzRte80aU6eoDsS1U+ec8w80obq0HmFc4zErSkUIF2FQfAFIfwO0OvCzFkFYMqWdSwU2tL6j97RFzpssc+iwAxuOzMFLXNW5YFRJG4J/TwEG6J6I6sdbOmJkhqFQeYQoMciH2LvUi8KVMlSw+HQWKnEyYApRYEFqBg5OmggOOkAyDNUFFl5Qf0qIdm2IfxTQ3EXG97I5KunRrdvRLgu5sMgr6qWZxDHrD8r1BGqS6Sb2MUp+JM0HOoJVc5iWXexUWSQC2XYU2gOBnFQUxyoS1G7y5gKSTd+wFDgH3MaEuShcshw4Gagq6pkuUkE8lKVDtmwRl/i19vqU5eZIbMnKHGVTLAbZJByl9Qzw6UylaED9ctyH/7a6t/qB4QfGSc86Ykf9RYc6AKVU+UDw0tIFRtqn8HnEt2RtGCcvL9Ai5ASl0iWsUdXazCtHlqIyvxSRepgYxCwKKyP+gBD8ylirxeCfzYHdQgECihndNRV1KvT1i303OP8rhUlKEqmBa5uRCUlYQQEFTD9oqEHPYyq1o0X5lf38zHlTnPZqSS5tv50EG/lyaqL6sQCL7cjBMCj0/v9RF6cBl00FaHa8ejS6aKV+TxOo66pLyXx2ObxiL/b8aRSHv8AeNHpAt+/DY/aMxMc9VJSNKbvEki8XpSqXP8Ap97RUlpr+fxFpHj7/eCASCZtPQfcxYwy+yLRSUYPJXTSKbIsX8bNdiHDpGri2m1oxMSqv4+4ix13ZTwAtwpFKapzEXwXFWbICDoG1/K5YfY+MBT7f37eLI963v6QIbBLDP7/ALxWi1N9/wBvd4qxMtxo3OjplOHkP3jWSHFH+g4VveObwc5ue9z4CNmTO3/3fiO2lJNHFXg73M7pmWGcMK6V3uYItYd39Nw8S6VU6a/gD2YCk2NLDXgPvHH1C8x6fQSdmWZM0CoUkHi7/SDfzZJSVKeoBq9AffkIzSqtIIic0c1kel4ra3NLEoACU0HeNW1nTG/2xa6PmyupxUldlys6P+7KLoZtwpY8Yj0zPAmkaV9VqP39Ir4bGZFA3oUnilaSlQ9TF7MiylRt6fPBWwRCZKUvUkrPB2SkeSX/ANUX5U5JnJCTTPJTa7Llj6h4qDEJCwQCyWahshgB6CI4af8A4qCXotKvJQP1g5FK0aWm+yDzMb2lqr2ipq1qXNH8POBdeD3go8lAceP0imhTtXS1YZc0Wd+Fd4ixt4uHds0MMQtQSmXcgd4k8bMIJ8VYhPWy0ggiXKQhk1YiqqinrGQmepNRTSux4QyMQVAAsw1A7x4+cbUm1hHndVpbXovubGCNAWNQPfoYljcQwv5jg14pJxAbT6cIBiZ/MeopHouajE8fw253KmNX7FR+0VZcNOW5hkmOCUrs70rItSfbQRR9n37aAylQ61xSZLWRKXE0LpFVSocLiWyrExMoBtAVGGeGeJuMIgwYH36xXTBgqKTE0KcfbxXgkwwKFIaCSVsY0JGIbh6kxlwWWfYioTaJlFM0cWtxXzJ96t5QGUvsJ8R629YETTQc6mJYdXZUNiD50P2hVHc06fyskVasYmDuDDJSYIl9rcf2jE7ky9jcaVlKmNU3GpzKL+bjwgCJlQWN2Pm/5hpamQkb5he3bUx829YAl3Z2/IP94AjNqKCfzBcgA+m8GlYdfeZmr2qel4B/NhPcTbVVTz4QKZMUodo6u2lXo2kMJTxnJZXLQnvrPJIry2ga8QGZCQni7k8z+IrO8RhA5t5I4hZPjEpSmGvv2IHNLkQ7c41jg4quZBuu4jxEBnTPYMRKuMCMVKTMlEjDiGhRmWFSqEVQOFDuKwiYTw0KEMUKFCgAcGJZohCgAkTEYUKABRJJiMOIALCTyHKHlmvMfv8AaIBXsQxMW9hLDLKVw6VnhAHhyqMbHXqDCYcvifq/3hsxJFQ9B+8ASqniftE0GsMlPAx2gg7p5j7wImJoPZPh94Ym8DE8YbhDP5wxMIpsjqYT8oimE8Wjme4yzEYRMNAwFChQoQChQoUAChQoUAChQoUAChQoUAChQoUAChQoUAE3hoYQoACkwniAh4RomTESB9IGDCeAEyTxJJofBoE8PmgBsd4YmGJhiYAbGeGeFDQzMUKFCgAUKFCgAUKFCgAUKFCgAUKFCgAUKFCgAUKFCgAUKFCgAUPDQoAHBhxChQhoQh3hQoAGeFChQwEYZ4UKAGNChQoBChQoUAChQoUAChQoUAChQoUAH//Z' }}
      style={styles.fundo}
      resizeMode="cover"
    >
      <View style={styles.overlay} />

      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.titulo}>🕸️ Sentido aranha ativado</Text>
        </View>

        <View style={styles.visor}>
          <View style={styles.linhaEmblema}>
            <View style={styles.emblema}>
              <Text style={styles.emblemaTexto}>🕷️</Text>
            </View>
          </View>
          <Text style={styles.expressaoTexto} numberOfLines={1}>
            {expressao === '' ? ' ' : expressao}
          </Text>
          <Text
            style={[styles.resultadoTexto, resultado === 'Erro' && styles.resultadoErro]}
            numberOfLines={1}
            adjustsFontSizeToFit
          >
            {resultado}
          </Text>
        </View>

        <View style={styles.teclado}>
          {teclado.map((linha, i) => (
            <View key={i} style={styles.linhaTeclas}>
              {linha.map((tecla) => (
                <TouchableOpacity
                  key={tecla}
                  style={styles.tecla}
                  onPress={() => apertar(tecla)}
                  activeOpacity={0.75}
                >
                  <LinearGradient
                    colors={corDaTecla(tecla).gradient}
                    style={styles.gradienteTecla}
                  >
                    <Text style={corDoTexto(tecla)}>{tecla}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          ))}
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  fundo: {
    flex: 1
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(10, 10, 20, 0.78)'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20
  },
  header: {
    marginBottom: 18,
    paddingHorizontal: 4
  },
  eyebrow: {
    fontSize: 13,
    fontWeight: '700',
    color: '#e62429',
    textTransform: 'uppercase',
    letterSpacing: 2,
    marginBottom: 6
  },
  titulo: {
    fontSize: 30,
    fontWeight: '800',
    color: '#f1f1f6',
    letterSpacing: -0.5
  },
  visor: {
    backgroundColor: 'rgba(16, 16, 28, 0.85)',
    borderRadius: 24,
    paddingVertical: 20,
    paddingHorizontal: 26,
    marginBottom: 20,
    borderWidth: 1.5,
    borderColor: '#26284a',
    minHeight: 150,
    justifyContent: 'flex-end'
  },
  linhaEmblema: {
    position: 'absolute',
    top: 14,
    left: 22
  },
  emblema: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#1c1c30',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#e62429'
  },
  emblemaTexto: {
    fontSize: 16
  },
  expressaoTexto: {
    fontSize: 20,
    fontWeight: '600',
    color: '#9aa6d8',
    marginBottom: 8,
    textAlign: 'right'
  },
  resultadoTexto: {
    fontSize: 46,
    fontWeight: '800',
    color: '#f1f1f6',
    letterSpacing: -1,
    textAlign: 'right'
  },
  resultadoErro: {
    color: '#e62429',
    fontSize: 32
  },
  teclado: {
    gap: 10
  },
  linhaTeclas: {
    flexDirection: 'row',
    gap: 10
  },
  tecla: {
    flex: 1,
    borderRadius: 18,
    overflow: 'hidden',
    aspectRatio: 1.3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 4
  },
  gradienteTecla: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  teclaNumero: { gradient: ['rgba(26,26,46,0.92)', 'rgba(19,19,31,0.92)'] },
  teclaOperador: { gradient: ['rgba(28,42,82,0.92)', 'rgba(16,24,48,0.92)'] },
  teclaLimpar: { gradient: ['rgba(58,13,18,0.92)', 'rgba(38,7,11,0.92)'] },
  teclaIgual: {  gradient: ['rgba(58,13,18,0.92)', 'rgba(38,7,11,0.92)'] },
  textoNumero: {
    fontSize: 22,
    fontWeight: '700',
    color: '#e8e8f2'
  },
  textoOperador: {
    fontSize: 24,
    fontWeight: '700',
    color: '#9aa6e8'
  },
  textoLimpar: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f08a8d'
  },
  textoIgual: {
    fontSize: 26,
    fontWeight: '800',
    color: '#fff'
  }
});